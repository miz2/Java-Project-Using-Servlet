import java.io.IOException;
import java.io.PrintWriter;
import static java.lang.System.out;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/viewemployee")
public class viewemployee extends HttpServlet {
    
    Connection con;
    PreparedStatement pst;
    ResultSet rs;
    int row;

    public void doGet(HttpServletRequest req,HttpServletResponse rsp ) throws IOException,ServletException
    {
        
        rsp.setContentType("text/html");
        PrintWriter out = rsp.getWriter();
        
        out.println("<link rel=\"stylesheet\" href=\"https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css\" integrity=\"sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T\" crossorigin=\"anonymous\">");
        out.println("<nav class=\"navbar navbar-expand-lg navbar-light bg-light\">\n" +
"  <a class=\"navbar-brand\" href=\"#\"> <h1 >XYZ Corporations Pvt Ltd.</h1></a>\n" +
"  <button class=\"navbar-toggler\" type=\"button\" data-toggle=\"collapse\" data-target=\"#navbarSupportedContent\" aria-controls=\"navbarSupportedContent\" aria-expanded=\"false\" aria-label=\"Toggle navigation\">\n" +
"    <span class=\"navbar-toggler-icon\"></span>\n" +
"  </button>\n" +
"     \n" +
"  </div>\n" +
"</nav>");
         
        out.println("<br>");
        out.println("<br>");
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3307/lba","root","");
           
            String sql;
            
            sql = "select * from employee";
            Statement stmt = con.createStatement();
            rs = stmt.executeQuery(sql);

out.println("<div style=\"text-align:center;\">");
out.println("<h1 style=\"font-size: 2em;\">Welcome to View Employee</h1>");
out.println("</div>");

out.println("<table style=\"margin: 0 auto; border-collapse: collapse;\" cellspacing='0' width='80%' border='1'>");
out.println("<tr>");
out.println("<th style=\"padding: 10px;\">EmpID</th>");
out.println("<th style=\"padding: 10px;\">Firstname</th>");
out.println("<th style=\"padding: 10px;\">Lastname</th>");
out.println("<th style=\"padding: 10px;\">Edit</th>");
out.println("<th style=\"padding: 10px;\">Delete</th>");
out.println("</tr>");
            
            while (rs.next()) {
    out.println("<tr>");
    out.println("<td style=\"padding: 10px;\">" + rs.getString("id") + "</td>");
    out.println("<td style=\"padding: 10px;\">" + rs.getString("fname") + "</td>");
    out.println("<td style=\"padding: 10px;\">" + rs.getString("lname") + "</td>");
    out.println("<td style=\"padding: 10px;\"><a href=\"EditServlet?id=" + rs.getString("id") + "\">Edit</a></td>");
    out.println("<td style=\"padding: 10px;\"><a href=\"Delete?id=" + rs.getString("id") + "\">Delete</a></td>");
    out.println("</tr>");
}

out.println("</table>");
 
            
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(employee.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
           
              out.println("<span style=\"color: red; font-weight: bold; text-shadow: 1px 1px gray; font-size: 1.2em; font-family: 'Open Sans', sans-serif;\">We Failed to fetch the records</span>");

             out.println("<span style=\"font-size: 1.2em;\"> <br>Try Again!! By using a different id:</span>");
 
        }
    }  
}