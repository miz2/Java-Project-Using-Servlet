import java.io.IOException;
import java.io.PrintWriter;
import static java.lang.System.out;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/Delete")
public class Delete extends HttpServlet {
    
    Connection con;
    PreparedStatement pst;
    ResultSet rs;
    int row;
    
    
    
    public void doGet(HttpServletRequest req,HttpServletResponse rsp ) throws IOException,ServletException
    {
          
        out.println("<br>");
        out.println("<br>");
        rsp.setContentType("text/html");
        PrintWriter out = rsp.getWriter();
        
        String empid = req.getParameter("id");
        
        out.println("<link rel=\"stylesheet\" href=\"https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css\" integrity=\"sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T\" crossorigin=\"anonymous\">");
        try {
             Class.forName("com.mysql.cj.jdbc.Driver");
             con = DriverManager.getConnection("jdbc:mysql://localhost:3307/lba","root","");
             pst = con.prepareStatement("delete from employee where id = ?");
             pst.setString(1, empid);
             row = pst.executeUpdate();
             out.println("<nav class=\"navbar navbar-expand-lg navbar-light bg-light\">\n" +
"  <a class=\"navbar-brand\" href=\"#\"> <h1 >XYZ Corporations Pvt Ltd.</h1></a>\n" +
"  <button class=\"navbar-toggler\" type=\"button\" data-toggle=\"collapse\" data-target=\"#navbarSupportedContent\" aria-controls=\"navbarSupportedContent\" aria-expanded=\"false\" aria-label=\"Toggle navigation\">\n" +
"    <span class=\"navbar-toggler-icon\"></span>\n" +
"  </button>\n" +
"     \n" +
"  </div>\n" +
"</nav>");
             out.println("<span style='color: green; font-weight: bold;'>Record deleted Successfully</span>");


            
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(employee.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
           out.println("<nav class=\"navbar navbar-expand-lg navbar-light bg-light\">\n" +
"  <a class=\"navbar-brand\" href=\"#\"> <h1 >XYZ Corporations Pvt Ltd.</h1></a>\n" +
"  <button class=\"navbar-toggler\" type=\"button\" data-toggle=\"collapse\" data-target=\"#navbarSupportedContent\" aria-controls=\"navbarSupportedContent\" aria-expanded=\"false\" aria-label=\"Toggle navigation\">\n" +
"    <span class=\"navbar-toggler-icon\"></span>\n" +
"  </button>\n" +
"     \n" +
"  </div>\n" +
"</nav>");
            out.println("<span style=\"color: red; font-weight: bold; text-shadow: 1px 1px gray; font-size: 1.2em; font-family: 'Open Sans', sans-serif;\">Record could not be deleted</span>");

             out.println("<span style=\"font-size: 1.2em;\"> <br>Try Again!! </span>");


        }
    
    
    }
    
}